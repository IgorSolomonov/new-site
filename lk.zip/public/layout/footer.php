            </div>
        </div>
                   <div class="footer">
            <div class="footerContact">
                <p class="paragraph">241519 Брянская область Брянский район поселок Путёвка улица Школьная, дом 1
                    <br/>т. 8(4832) 92-53-96</p>
            </div>
            <div class="footerButton">
                <a href="feedback.html" class="btn w-button">ОБРАТНАЯ СВЯЗЬ</a>
               <?php echo $locked;?>
            
            </div>
        </div>
    </div>

<!-- JQuery section -->
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/custom.js"></script>
</body>

</html>