<div class="footer">
        
        <div class="paragraph">241519 Брянская область Брянский район поселок Путёвка улица Школьная, дом 1
            <br/>т. 8(4832) 92-53-96</div>
    
</div>
<!-- JQuery section -->
<script src="js/custom.js"></script>
</body>
</html>