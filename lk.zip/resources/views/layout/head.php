<!DOCTYPE HTML>
<html>
<head>
    <!-- -->
    <meta charset="UTF-8">
    <!--название сайта-->
    <title>Личный кабинет</title>
    <!--сброс настроек css-->
    <!-- <link rel="stylesheet" type="text/css" href="css/reset.css"> -->
    <!--настроеки css -->
    <link rel="stylesheet" type="text/css" href='css/app.css?version=5'>
    <link rel="stylesheet" type="text/css" href="css/media.css">
    <!--для адаптиности -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--для фавиконки -->
    <link rel="shortcut icon" type="image/x-icon" href="css/icon/icon100.png">
</head>
<body>
    <div class='header'>
        <div class="title">Личный кабинет сотрудника</div>
    </div>