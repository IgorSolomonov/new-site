@include('layout.head')
<body>
<div class="wrapper">
<div class='header'>
    <div class="title">Личный кабинет сотрудника</div>
{{-- @include('layout.footer') --}}
<!-- JQuery section -->
<script src="js/custom.js"></script>
</body>
</html>