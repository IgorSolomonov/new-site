<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<div class="wrapper">
<div class='header'>
    <div class="title">Личный кабинет сотрудника</div>
</div>
<?php echo e($tel); ?>

<?php echo e($pin); ?>


</div>

<!-- JQuery section -->
<script src="js/custom.js"></script>
</body>
</html><?php /**PATH C:\OSPanel\domains\lk\resources\views/post.blade.php ENDPATH**/ ?>