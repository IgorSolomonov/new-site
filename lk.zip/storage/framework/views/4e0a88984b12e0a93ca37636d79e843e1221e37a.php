<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="teacher">
    
    <div class="name"><?php echo e(($name)); ?></div>
    <div class="payslip">
        <a href="<?php echo e($path); ?>"><img src="css/icon/icon100.png"><br><?php echo e($month); ?></a>
    </div>
    <div class="teacher_exit">
        <a href="<?php echo e(route('home')); ?>">Выход</a>
    </div>
</div>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html><?php /**PATH C:\OSPanel\domains\lk\resources\views/teacher.blade.php ENDPATH**/ ?>